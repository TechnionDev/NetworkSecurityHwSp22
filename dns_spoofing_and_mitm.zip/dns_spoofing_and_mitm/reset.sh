rm -r client/lib/
rm -r attacker/lib/
rm -r log

mkdir client/lib/
mkdir attacker/lib/
mkdir log
